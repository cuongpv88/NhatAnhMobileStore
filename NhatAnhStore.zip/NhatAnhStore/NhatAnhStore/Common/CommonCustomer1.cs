﻿namespace NhatAnhStore.Common
{
    public static class CommonCustomer
    {
        public static string Code = "Code";
    }
}
