﻿namespace NhatAnhStore.Common
{
    public static class CommonAdmin
    {
        public static string USER_SESSION = "USER_SESSION";
        public static string NAME_SESSION = "NANE_SESSION";
        public static string ROLE_SESSION = "ROLE";
        public static string Code = "Code";

    }
}
