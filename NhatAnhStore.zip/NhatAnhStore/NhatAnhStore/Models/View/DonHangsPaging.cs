﻿
using System.Collections.Generic;

namespace NhatAnhStore.Models.View
{
    public class DonHangsPaging
    {
        public List<DonHang> DonHangs { get; set; }
        public PagingInfo PagingInfo { get; set; }
    }
}
