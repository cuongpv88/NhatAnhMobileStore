﻿using System.Collections.Generic;

namespace NhatAnhStore.Models.View
{
    public class DienThoaisPaging
    {
        public List<DienThoai> DienThoais { get; set; }
        public PagingInfo PagingInfo { get; set; }
    }
}
