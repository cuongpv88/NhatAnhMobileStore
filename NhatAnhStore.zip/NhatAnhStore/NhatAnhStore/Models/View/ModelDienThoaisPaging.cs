﻿using System.Collections.Generic;

namespace NhatAnhStore.Models.View
{
    public class ModelDienThoaisPaging
    {
        public List<ModelDienThoai> ModelDienThoais { get; set; }
        public PagingInfo PagingInfo { get; set; }
    }
}
