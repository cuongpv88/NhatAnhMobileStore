﻿using System.Collections.Generic;

namespace NhatAnhStore.Models.View
{
    public class KhachHangsPaging
    {
        public List<KhachHang> KhachHangs { get; set; }
        public PagingInfo PagingInfo { get; set; }
    }
}
