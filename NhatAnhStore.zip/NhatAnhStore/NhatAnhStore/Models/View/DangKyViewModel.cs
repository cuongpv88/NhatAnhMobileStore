﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NhatAnhStore.Models;

namespace NhatAnhStore.Models.View
{
    public class DangKyViewModel
    {
        public TaiKhoan TaiKhoan { get; set; }
        public KhachHang KhachHang { get; set; }
    }
}
