﻿using System;
using System.Linq;
using System.Threading.Tasks;
using NhatAnhStore.Areas.Identity.Services;
using NhatAnhStore.Common;
using NhatAnhStore.Data;
using NhatAnhStore.Models.View;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace NhatAnhStore.Areas.Customer.Identity
{
    [Area("Customer")]
    public class ForgotPasswordController : Controller
    {
        private readonly NhatAnhDbContext _mb;
        private readonly EmailSender _emailSender;
        [BindProperty]
        public ForgotPasswordViewModel Input { get; set; }
        public ForgotPasswordController(NhatAnhDbContext mb, EmailSender emailSender)
        {
            _mb = mb;
            _emailSender = emailSender;
            Input = new ForgotPasswordViewModel();

        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost, ActionName("Index")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> XacNhan()
        {
            if (ModelState.IsValid)
            {
                var taiKhoan = _mb.TaiKhoan.Include(tk=> tk.KhachHang).Where(tk => tk.KhachHang.Email == Input.Email).SingleOrDefault();
                if (taiKhoan != null && taiKhoan.KhachHang.Email == Input.Email)
                {
                    if (!taiKhoan.TrangThai)
                    {
                        ModelState.AddModelError("", "Tài khoản đang bị khóa.");
                        return View("Index");
                    }
                    else
                    {
                        try
                        {
                            string code = CreateMaXacNhan();
                            HttpContext.Session.SetString(CommonCustomer.Code, code);
                            await _emailSender.SendEmailAsync(
                            Input.Email,
                            "Đặt lại mật khẩu",
                            $"Xin chào {taiKhoan.KhachHang.TenKH}!<br>Mã xác nhận của tài khoản '{taiKhoan.TenTK}' là: <h2>{code}</h2>Hãy dùng mã này để đặt lại mật khẩu. Mã có thời hạn trong 1 tiếng");

                            return RedirectToAction("ResetPass", "ResetPassword", new { Input.Email });
                        }
                        catch
                        {
                            return View("Index");
                        }

                    }

                }
                else
                {
                    ModelState.AddModelError("", "Email không tồn tại.");
                }
            }
            return View("Index");
        }

        private string CreateMaXacNhan()
        {
            Random rd = new Random();
            return rd.Next(100001, 999999).ToString();
        }
    }
}