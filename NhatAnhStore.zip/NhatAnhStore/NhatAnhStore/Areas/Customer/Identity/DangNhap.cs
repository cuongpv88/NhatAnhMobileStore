﻿namespace NhatAnhStore.Areas.Customer.Identity
{
    public class DangNhap
    {
        public int MaKH;
        public string TenKH;
    }
}
