﻿namespace NhatAnhStore.Utility
{
    public class SD
    {
        public const string DefaultProductImage = "default_image.png";
        public const string ImageFolderModelDienThoai = @"images\ModelDienThoai";
        public const string ImageFolderDienThoai = @"images\DienThoai";
    }
}
